# Graph Traversal and Shortest Paths (Fall 2026)

Language: Java 17 or newer (tested with OpenJDK 21). No graph library is used.

## How to run
From this folder:

    javac Task1BFS.java Task2DFS.java Task3Dijkstra.java
    java Task1BFS
    java Task2DFS
    java Task3Dijkstra


