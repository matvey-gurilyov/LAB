import java.io.PrintStream;
import java.util.*;

public class Task1BFS {

    static Map<String, List<String>> buildG1() {
        Map<String, List<String>> g = new LinkedHashMap<>();
        String[] edges = {
            "S A", "S B", "A C", "A D", "B D", "B E", "C F", "D F",
            "E G", "F H", "G H", "H T", "X Y", "X Z", "Y Z"
        };
        for (String e : edges) {
            String[] p = e.split(" ");
            g.computeIfAbsent(p[0], k -> new ArrayList<>()).add(p[1]);
            g.computeIfAbsent(p[1], k -> new ArrayList<>()).add(p[0]);
        }
        for (List<String> nb : g.values()) Collections.sort(nb); // alphabetical
        return g;
    }

    record BfsResult(List<String> order, Map<String, Integer> level, Map<String, String> parent) {}

    static BfsResult bfs(Map<String, List<String>> g, String start, boolean trace) {
        List<String> order = new ArrayList<>();
        Map<String, Integer> level = new LinkedHashMap<>();   // also acts as "visited"
        Map<String, String> parent = new LinkedHashMap<>();
        Deque<String> queue = new ArrayDeque<>();

        queue.offer(start);
        level.put(start, 0);
        parent.put(start, null);
        if (trace) System.out.println("Start        queue = " + queue);

        while (!queue.isEmpty()) {
            String u = queue.poll();
            order.add(u);
            for (String v : g.get(u)) {
                if (!level.containsKey(v)) {
                    level.put(v, level.get(u) + 1);
                    parent.put(v, u);
                    queue.offer(v);
                }
            }
            if (trace) System.out.printf("Dequeue %-3s queue = %-24s visit order = %s%n", u, queue, order);
        }
        return new BfsResult(order, level, parent);
    }

    static List<String> shortestPath(Map<String, String> parent, String target) {
        if (!parent.containsKey(target)) return null;   // unreachable
        LinkedList<String> path = new LinkedList<>();
        for (String v = target; v != null; v = parent.get(v)) path.addFirst(v);
        return path;
    }

    static void lateMarkingDemo(Map<String, List<String>> g, String start) {
        Set<String> marked = new HashSet<>();
        Deque<String> queue = new ArrayDeque<>();
        List<String> order = new ArrayList<>();
        int enqueues = 1, skipped = 0;
        queue.offer(start);
        while (!queue.isEmpty()) {
            String u = queue.poll();
            if (!marked.add(u)) { skipped++; continue; }
            order.add(u);
            for (String v : g.get(u))
                if (!marked.contains(v)) { queue.offer(v); enqueues++; }
        }
        System.out.println("  (mark on dequeue) order = " + order);
        System.out.println("  enqueue operations = " + enqueues + " (instead of " + order.size()
                + "), duplicate copies skipped = " + skipped);
    }

    public static void main(String[] args) throws Exception {
        System.setOut(new PrintStream(System.out, true, "UTF-8"));
        Map<String, List<String>> g = buildG1();

        System.out.println("=== (a) Trace of BFS from S ===");
        BfsResult r = bfs(g, "S", true);

        System.out.println();
        System.out.println("=== Results (expected-output format) ===");
        System.out.println("Visit order : " + String.join(" ", r.order()));

        StringBuilder lv = new StringBuilder();
        for (String v : r.order()) lv.append(v).append('=').append(r.level().get(v)).append(' ');
        System.out.println("Levels      : " + lv.toString().trim());

        List<String> path = shortestPath(r.parent(), "T");
        System.out.println("Path S -> T : " + String.join(" ", path) + " (" + (path.size() - 1) + " edges)");

        List<String> unreached = new ArrayList<>();
        for (String v : g.keySet()) if (!r.level().containsKey(v)) unreached.add(v);
        System.out.println("Unreached   : " + String.join(" ", unreached));

        System.out.println();
        System.out.println("=== Written question: marking on dequeue instead of enqueue ===");
        lateMarkingDemo(g, "S");
    }
}
