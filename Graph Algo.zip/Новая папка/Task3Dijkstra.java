import java.io.PrintStream;
import java.util.*;

public class Task3Dijkstra {

    static final int INF = Integer.MAX_VALUE;

    static Map<String, Map<String, Integer>> buildG2() {
        Map<String, Map<String, Integer>> g = new LinkedHashMap<>();
        String[][] edges = {
            {"Tashkent", "Samarkand", "3"}, {"Tashkent", "Navoi", "5"},
            {"Samarkand", "Navoi", "2"},    {"Samarkand", "Qarshi", "4"},
            {"Navoi", "Bukhara", "2"},      {"Qarshi", "Bukhara", "3"},
            {"Qarshi", "Termez", "5"},      {"Bukhara", "Khiva", "6"},
            {"Termez", "Khiva", "9"},       {"Bukhara", "Termez", "8"}
        };
        for (String[] e : edges) setEdge(g, e[0], e[1], Integer.parseInt(e[2]));
        return g;
    }

    static void setEdge(Map<String, Map<String, Integer>> g, String a, String b, int w) {
        g.computeIfAbsent(a, k -> new TreeMap<>()).put(b, w);
        g.computeIfAbsent(b, k -> new TreeMap<>()).put(a, w);
    }

    static Map<String, Map<String, Integer>> copy(Map<String, Map<String, Integer>> g) {
        Map<String, Map<String, Integer>> c = new LinkedHashMap<>();
        for (var e : g.entrySet()) c.put(e.getKey(), new TreeMap<>(e.getValue()));
        return c;
    }

    record Result(Map<String, Integer> dist, Map<String, String> prev, List<String> settleOrder) {}

    record Item(String v, int d) {}

    static Result dijkstra(Map<String, Map<String, Integer>> g, String source, boolean trace) {
        Map<String, Integer> dist = new LinkedHashMap<>();
        Map<String, String> prev = new LinkedHashMap<>();
        for (String v : g.keySet()) { dist.put(v, INF); prev.put(v, null); }
        dist.put(source, 0);

        List<String> settleOrder = new ArrayList<>();
        Set<String> settled = new HashSet<>();
        PriorityQueue<Item> pq = new PriorityQueue<>(
                Comparator.comparingInt(Item::d).thenComparing(Item::v));
        pq.add(new Item(source, 0));
        int step = 0;

        while (!pq.isEmpty()) {
            Item top = pq.poll();
            String u = top.v();
            if (settled.contains(u)) continue;
            settled.add(u);
            settleOrder.add(u);
            step++;
            if (trace) System.out.println("--- Step " + step + ": take " + u + " (dist = " + dist.get(u) + ") ---");

            for (var e : g.get(u).entrySet()) {
                String v = e.getKey();
                int w = e.getValue();
                if (settled.contains(v)) continue;
                long alt = (long) dist.get(u) + w;
                boolean better = alt < (dist.get(v) == INF ? Long.MAX_VALUE : dist.get(v));
                if (trace) {
                    String dv = dist.get(v) == INF ? "INF" : String.valueOf(dist.get(v));
                    System.out.printf("  dist[%s] + w < dist[%s]:  %d + %d < %s  -> %s%n",
                            u, v, dist.get(u), w, dv, better ? "yes, update" : "no");
                }
                if (better) {
                    dist.put(v, (int) alt);
                    prev.put(v, u);
                    pq.add(new Item(v, (int) alt));
                }
            }
            if (trace) printTable(g, dist, prev, settled, u);
        }
        return new Result(dist, prev, settleOrder);
    }

    static void printTable(Map<String, Map<String, Integer>> g, Map<String, Integer> dist,
                           Map<String, String> prev, Set<String> settled, String current) {
        System.out.printf("  %-10s %-5s %-10s %s%n", "Vertex", "dist", "prev", "Status");
        for (String v : g.keySet()) {
            String status;
            if (v.equals(current)) status = "current";
            else if (settled.contains(v)) status = "settled";
            else if (dist.get(v) != INF) status = "candidate";
            else status = "unvisited";
            System.out.printf("  %-10s %-5s %-10s %s%n", v,
                    dist.get(v) == INF ? "INF" : dist.get(v),
                    prev.get(v) == null ? "-" : prev.get(v), status);
        }
        System.out.println();
    }

    static List<String> route(Map<String, String> prev, String target) {
        LinkedList<String> path = new LinkedList<>();
        for (String v = target; v != null; v = prev.get(v)) path.addFirst(v);
        return path;
    }

    static void printRoutes(Map<String, Map<String, Integer>> g, Result r, String source) {
        System.out.printf("%-10s %-5s %s%n", "To", "Cost", "Cheapest route");
        for (String v : g.keySet()) {
            if (v.equals(source)) continue;
            if (r.dist().get(v) == INF) {
                System.out.printf("%-10s %-5s %s%n", v, "INF", "unreachable");
                continue;
            }
            System.out.printf("%-10s %-5d %s%n", v, r.dist().get(v), String.join(" → ", route(r.prev(), v)));
        }
        System.out.println("Settle order: " + String.join(", ", r.settleOrder()) + ".");
    }

    public static void main(String[] args) throws Exception {
        System.setOut(new PrintStream(System.out, true, "UTF-8"));
        String src = "Tashkent";
        Map<String, Map<String, Integer>> g = buildG2();

        System.out.println("=== (a) Trace of Dijkstra from Tashkent ===");
        Result base = dijkstra(g, src, true);

        System.out.println("=== (b)+(c) Results for the original G2 ===");
        printRoutes(g, base, src);

        System.out.println();
        System.out.println("=== (d) What-if: Samarkand-Qarshi = 1 hour ===");
        Map<String, Map<String, Integer>> g2 = copy(g);
        setEdge(g2, "Samarkand", "Qarshi", 1);
        Result what = dijkstra(g2, src, false);
        printRoutes(g2, what, src);
        System.out.println("Changes compared with the original:");
        for (String v : g.keySet()) {
            if (v.equals(src)) continue;
            String oldR = String.join(" → ", route(base.prev(), v));
            String newR = String.join(" → ", route(what.prev(), v));
            boolean costChanged = !base.dist().get(v).equals(what.dist().get(v));
            if (costChanged || !oldR.equals(newR))
                System.out.printf("  %-10s cost %d -> %d | route: %s  =>  %s%n", v,
                        base.dist().get(v), what.dist().get(v), oldR, newR);
        }

        System.out.println();
        System.out.println("=== (e) Negative edge: Navoi-Bukhara = -4 (copy of G2) ===");
        Map<String, Map<String, Integer>> g3 = copy(g);
        setEdge(g3, "Navoi", "Bukhara", -4);
        Result neg = dijkstra(g3, src, false);
        printRoutes(g3, neg, src);
 
        System.out.println("Note: Dijkstra settled Navoi with dist 5 and never revisited it, yet");
        System.out.println("      Tashkent -> Navoi -> Bukhara -> Navoi = 5 - 4 - 4 = -3 < 5.");
    }
}
