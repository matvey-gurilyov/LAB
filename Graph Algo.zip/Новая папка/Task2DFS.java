import java.io.PrintStream;
import java.util.*;

public class Task2DFS {

    static Map<String, List<String>> buildG1() {
        Map<String, List<String>> g = new LinkedHashMap<>();
        String[] edges = {
            "S A", "S B", "A C", "A D", "B D", "B E", "C F", "D F",
            "E G", "F H", "G H", "H T", "X Y", "X Z", "Y Z"
        };
        for (String e : edges) {
            String[] p = e.split(" ");
            addEdge(g, p[0], p[1]);
        }
        for (List<String> nb : g.values()) Collections.sort(nb);
        return g;
    }

    static void addEdge(Map<String, List<String>> g, String a, String b) {
        g.computeIfAbsent(a, k -> new ArrayList<>()).add(b);
        g.computeIfAbsent(b, k -> new ArrayList<>()).add(a);
    }

    static List<String> dfs(Map<String, List<String>> g, String start, boolean trace) {
        List<String> order = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        Deque<String> stack = new ArrayDeque<>();
        stack.push(start);
        if (trace) System.out.println("Start         stack (top left) = " + stack);

        while (!stack.isEmpty()) {
            String u = stack.pop();
            if (visited.contains(u)) {
                if (trace) System.out.printf("Pop %-3s SKIPPED (duplicate)   stack = %s%n", u, stack);
                continue;
            }
            visited.add(u);
            order.add(u);
            List<String> nb = g.get(u);
            for (int i = nb.size() - 1; i >= 0; i--)
                if (!visited.contains(nb.get(i))) stack.push(nb.get(i));
            if (trace) System.out.printf("Pop %-3s visit             stack = %-28s order = %s%n", u, stack, order);
        }
        return order;
    }


    static void dfsRec(Map<String, List<String>> g, String u, Set<String> visited, List<String> order) {
        visited.add(u);
        order.add(u);
        for (String v : g.get(u))
            if (!visited.contains(v)) dfsRec(g, v, visited, order);
    }


    static List<List<String>> components(Map<String, List<String>> g) {
        List<String> vertexOrder = new ArrayList<>(g.keySet());
        Set<String> visited = new HashSet<>();
        List<List<String>> comps = new ArrayList<>();
        for (String s : vertexOrder) {
            if (visited.contains(s)) continue;
            List<String> members = new ArrayList<>();
            dfsRec(g, s, visited, members);
            members.sort(Comparator.comparingInt(vertexOrder::indexOf));
            comps.add(members);
        }
        return comps;
    }

    static boolean hasCycle(Map<String, List<String>> g) {
        Set<String> visited = new HashSet<>();
        for (String s : g.keySet())
            if (!visited.contains(s) && cycleFrom(g, s, null, visited)) return true;
        return false;
    }

    private static boolean cycleFrom(Map<String, List<String>> g, String u, String parent, Set<String> visited) {
        visited.add(u);
        for (String v : g.get(u)) {
            if (!visited.contains(v)) {
                if (cycleFrom(g, v, u, visited)) return true;
            } else if (!v.equals(parent)) {
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) throws Exception {
        System.setOut(new PrintStream(System.out, true, "UTF-8"));
        Map<String, List<String>> g = buildG1();

        System.out.println("=== (a) Trace of iterative DFS from S ===");
        List<String> iter = dfs(g, "S", true);

        System.out.println();
        System.out.println("=== (c) Recursive vs iterative ===");
        List<String> rec = new ArrayList<>();
        dfsRec(g, "S", new HashSet<>(), rec);
        System.out.println("Iterative : " + String.join(" ", iter));
        System.out.println("Recursive : " + String.join(" ", rec));
        System.out.println("Same order? " + iter.equals(rec));

        System.out.println();
        System.out.println("=== Results (expected-output format) ===");
        System.out.println("DFS order from S : " + String.join(" ", iter));
        List<List<String>> comps = components(g);
        System.out.println("Components : " + comps.size());
        for (int i = 0; i < comps.size(); i++)
            System.out.println(" #" + (i + 1) + " : " + String.join(" ", comps.get(i)));

        System.out.println("Has cycle (G1) : " + hasCycle(g));


        Map<String, List<String>> tree = new LinkedHashMap<>();
        addEdge(tree, "S", "A");
        addEdge(tree, "S", "B");
        addEdge(tree, "A", "C");
        addEdge(tree, "A", "D");
        addEdge(tree, "B", "E");
        for (List<String> nb : tree.values()) Collections.sort(nb);
        System.out.println("Has cycle (tree) : " + hasCycle(tree));
    }
}
